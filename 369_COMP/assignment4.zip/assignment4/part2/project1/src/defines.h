/* Allegro datafile object indexes, produced by dat v4.4.2, Unix */
/* Datafile: spacetime.dat */
/* Date: Sun Mar 19 18:40:05 2017 */
/* Do not hand edit! */

#define BACKMUSIC_WAV                    0        /* SAMP */
#define ENEMY_HORZ_BMP                   1        /* BMP  */
#define ENEMY_VERT_BMP                   2        /* BMP  */
#define SPEEDSHIP_BMP                    3        /* BMP  */
#define THE_IRIS_NEBULA_BMP              4        /* BMP  */

