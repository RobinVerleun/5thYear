/* Allegro datafile object indexes, produced by dat v4.4.2, Unix */
/* Datafile: flappy.dat */
/* Date: Wed Mar 15 01:00:17 2017 */
/* Do not hand edit! */

#define BACKGROUNDTILE_BMP               0        /* BMP  */
#define GAMEMAP_FMP                      1        /* DATA */
#define HUNDOULUO_WAV                    2        /* SAMP */
#define SCIFI_PLATFORMTILES_32X32_PNG    3        /* PNG  */
#define SPACESHIP_BMP                    4        /* BMP  */

